package com.members;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembersApplicationTests {

	@Test
	void contextLoads() {
	}

}
